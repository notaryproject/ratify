# Ratify Helm Chart

## Get Repo Info

```console
helm repo add ratify https://notaryproject.github.io/ratify
helm repo update
```

_See [helm repo](https://helm.sh/docs/helm/helm_repo/) for command documentation._

## Install Chart

```console
# Helm install with gatekeeper-system namespace already created
$ helm install [RELEASE_NAME] ratify/ratify-gatekeeper-provider --atomic --namespace gatekeeper-system --set image.tag=<RELEASE_TAG>

# Helm install and create namespace
$ helm install [RELEASE_NAME] ratify/ratify-gatekeeper-provider --atomic --namespace gatekeeper-system --create-namespace --set image.tag=<RELEASE_TAG>
```

_See [parameters](#parameters) below._

_See [helm install](https://helm.sh/docs/helm/helm_install/) for command documentation._

## Upgrade Chart

```console
$ helm upgrade -n gatekeeper-system [RELEASE_NAME] ratify/ratify-gatekeeper-provider --set image.tag=<RELEASE_TAG>
```

### Upgrading CRDs

> [!IMPORTANT]
> Helm intentionally does **not** update CRDs that ship in a chart's `crds/`
> directory during `helm upgrade` — it only installs them on the first
> `helm install`. See
> [Helm's CRD limitations](https://helm.sh/docs/chart_best_practices/custom_resource_definitions/#some-caveats-and-explanations).

When a release of this chart changes the `config.ratify.sh` CRDs (for example
adding the `v2beta1` version of `Executor` / `NamespacedExecutor`), a plain
`helm upgrade` will keep the **old** CRDs. Because the Ratify controllers watch
the new storage version and the bundled `Executor` hook object uses it, running
against stale CRDs can cause the controller to fail to start or the pre-upgrade
hook to be rejected by the API server.

While Ratify v2 is in the `beta` phase, CRD changes are delivered by
**reinstalling** the chart rather than through an automated in-place upgrade:

```console
# 1. Uninstall the existing release (custom resources you created are preserved;
#    only the release's templated objects are removed).
$ helm uninstall -n gatekeeper-system [RELEASE_NAME]

# 2. Apply the updated CRDs shipped with the new chart version.
$ helm pull ratify/ratify-gatekeeper-provider --version <NEW_CHART_VERSION> --untar
$ kubectl apply -f ratify-gatekeeper-provider/crds/

# 3. Reinstall the chart at the new version.
$ helm install [RELEASE_NAME] ratify/ratify-gatekeeper-provider \
    --atomic --namespace gatekeeper-system --set image.tag=<RELEASE_TAG>
```

Alternatively, apply the CRDs directly from the tag before upgrading:

```console
$ kubectl apply -f https://raw.githubusercontent.com/notaryproject/ratify/<RELEASE_TAG>/deployments/ratify-gatekeeper-provider/crds/executors.config.ratify.sh.yaml
$ kubectl apply -f https://raw.githubusercontent.com/notaryproject/ratify/<RELEASE_TAG>/deployments/ratify-gatekeeper-provider/crds/namespacedexecutors.config.ratify.sh.yaml
```

The `v2alpha1` version is retained as a served, deprecated version alongside the
new `v2beta1` storage version, and both share an identical schema (conversion
strategy `None`), so existing `v2alpha1` objects continue to be readable once the
updated CRDs are applied.

## Deprecation Policy

Values marked `# DEPRECATED` in the `values.yaml` as well as **DEPRECATED** in the below parameters will NOT be supported in the next major version release. Existing functionality will remain backwards compatible until the next major version release.

## Parameters
| Parameter                                 | Description                                                                                                                                                                                                                                  | Default                                         |
|--------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------|
| `image.repository`                        | Ratify app image                                                                                                                                                                                                                            | `ghcr.io/notaryproject/ratify-gatekeeper-provider` |
| `image.tag`                               | Image tag                                                                                                                                                                                                                                   | `<INSERT THE LATEST RELEASE TAG>`               |
| `image.pullPolicy`                        | Image pull policy                                                                                                                                                                                                                           | `IfNotPresent`                                  |
| `replicaCount`                            | Number of replicas to run                                                                                                                                                                                                                   | `1`                                             |
| `logger.level`                            | Log level for the provider (`panic`, `fatal`, `error`, `warning`, `info`, `debug`, `trace`).                                                                                                         | `info`                                          |
| `resources.requests.cpu`                  | CPU request for the provider container. Required for CPU-based autoscaling (HPA).                                                                                                                     | `600m`                                          |
| `resources.requests.memory`               | Memory request for the provider container.                                                                                                                                                           | `512Mi`                                         |
| `resources.limits.cpu`                    | CPU limit for the provider container.                                                                                                                                                                | `1000m`                                         |
| `resources.limits.memory`                 | Memory limit for the provider container.                                                                                                                                                              | `512Mi`                                         |
| `metrics.enabled`                         | Expose the Prometheus `/metrics` endpoint (adds the container port and pod scrape annotations).                                                                                                      | `true`                                          |
| `metrics.port`                            | Port for the `/metrics` endpoint.                                                                                                                                                                    | `8888`                                          |
| `notation.scopes`                         | Scopes that Notation verifier is applicable for. See [Notation trust policy](https://github.com/notaryproject/specifications/blob/main/specs/trust-store-trust-policy.md#trust-policy).                 | `[]`                                            |
| `notation.trustedIdentities`              | List of trusted identities for Notation verifier. See [Notation trust policy](https://github.com/notaryproject/specifications/blob/main/specs/trust-store-trust-policy.md#trust-policy).                | `[]`                                            |
| `notation.certs`                          | List of trusted root certificates for Notation verifier.                                                                                                                                              | `[]`                                            |
| `stores[0].scopes`                        | Scopes that the store is applicable for. If it's not set, it will be overridden by the executor's scopes.                                                                                                                                                             | `[]`                                            |
| `stores[0].username`                      | Username to authenticate to the store.                                                                                                                                                               | `""`                                            |
| `executor.scopes`                         | Scopes that the executor is applicable for. And it MUST NOT be empty for the executor to be valid.                                                                                                                                                              | `[]`                                            |
| `executor.concurrency`                    | The maximum number of concurrent execution per validation request.                                                                                                                                  | `3`                                            |
| `stores[0].password`                      | Password to authenticate to the store.                                                                                                                                                               | `""`                                            |
| `provider.tls.crt`                        | Ratify Gatekeeper Provider's TLS public certificate.                                                                                                                                                 | `""`                                            |
| `provider.tls.key`                        | Ratify Gatekeeper Provider's TLS private key.                                                                                                                                                        | `""`                                            |
| `provider.tls.caCert`                     | CA certificate to verify the TLS certificate.                                                                                                                                                        | `""`                                            |
| `provider.tls.disableCertRotation`        | Disable automatic TLS certificate rotation. When cert rotation is enabled, tls.crt, tls.key and tls.caCert are not required.                                                                         | `false`                                         |
| `provider.disableCRDManager`              | Disable CRD manager to manage the executor CRDs. This is useful when you want to configure executors through mounted config.json.                                                                | `false`                                         |
| `provider.disableMutation`                | Enables/disables tag-to-digest mutation for all admission resource creations. It is highly recommended to enable mutation since the verified digest may be different from the one run.                | `false`                                         |
| `provider.mutationExcludedNamespaces`     | Additional namespaces to exclude from the mutation webhook `Assign` objects, beyond the hardcoded defaults (`gatekeeper-system`, `kube-system`, release namespace). Use this to exclude critical infrastructure namespaces (e.g. CNI DaemonSet namespaces) that must not be blocked when Ratify is temporarily unavailable. | `[]`                                            |
| `provider.timeout.validationTimeoutSeconds`| Verify request handler timeout in seconds. This MUST match the configured Gatekeeper `validatingWebhookTimeoutSeconds`.                                                                              | `5`                                             |
| `provider.timeout.mutationTimeoutSeconds` | Mutate request handler timeout in seconds. This MUST match the configured Gatekeeper `mutatingWebhookTimeoutSeconds`.                                                                                | `2`                                             |
| `gatekeeper.namespace`                    | Namespace where Gatekeeper is installed. This MUST match the configured Gatekeeper `namespace`.                                                                                                      | `gatekeeper-system`                             |
| `serviceAccount.create`                   | Create new dedicated Ratify service account                                                                                                                                                          | `true`                                          |
| `serviceAccount.name`                     | Name of Ratify Gatekeeper Provider service account to create                                                                                                                                         | `ratify-gatekeeper-provider-admin`              |
| `serviceAccount.annotations`              | Annotations to add to the service account                                                                                                                                                            | `{}`                                            |
| `cosign.scopes` | Scopes that Cosign verifier is applicable for. If it's not set, it will be overridden by the executor's scopes.                                                                                                                              | `[]`                                            |
| `cosign.certificateIdentity`              | The expected certificate identity in the Cosign signature. |                                                                                                                                               | `""`                                            |
| `cosign.certificateIdentityRegex`       | The expected certificate identity Regex in the Cosign signature. |                                                                                                                                               | `""`                                            |
| `cosign.certificateOIDCIssuer`              | The expected OIDC issuer in the Cosign signature. |                                                                                                                                               | `""`                                            |
| `cosign.certificateOIDCIssuerRegex`       | The expected OIDC issuer Regex in the Cosign signature. |                                                                                                                                               | `""`                                            |
| `cosign.ignoreTLog`                     | Whether to ignore transparency log verification in Cosign verifier.                                                                                                                                   | `false`                                         |
| `cosign.ignoreCTLog`                    | Whether to ignore certificate transparency log verification in Cosign verifier. Only applies to keyless verification; it has no effect on key-based verification, which never involves the certificate transparency log.                  | `false`                                         |
| `cosign.ignoreObserverTimestamps`       | Whether to skip observer timestamp verification (RFC3161 timestamp or transparency-log SignedEntryTimestamp) for key-based verification, allowing offline key-signed images with no timestamp. Only applies to key-based verification. Combine with `cosign.ignoreTLog=true` to verify fully offline images signed with `--tlog-upload=false`. | `false`                                         |
| `cosign.keys.provider`                    | The provider type of the public keys. Supported values include `inline`, `azurekeyvault`.                                                                                                                                         | `inline`                                        |
| `cosign.keys.key`                         | The public keys used to verify the Cosign signature. This field is required when `cosign.keys.provider` is `inline`.                                                                                                                | `""`                                            |
| `cosign.keys.vaultURL`                   | The URL of the Azure Key Vault. This field is required when `cosign.keys.provider` is `azurekeyvault`.                                                                                               | `""`                                            |
| `cosign.keys.clientID`                   | The client ID for Azure Key Vault authentication. This field is optional when `cosign.keys.provider` is `azurekeyvault`.                                                                              | `""`                                            |
| `cosign.keys.tenantID`                   | The tenant ID for Azure Key Vault authentication. This field is optional when `cosign.keys.provider` is `azurekeyvault`.                                                                              | `""`                                            |
| `cosign.keys.keys`                       | List of keys to retrieve from Azure Key Vault. Each key should have `name` and optional `version`. This field is required when `cosign.keys.provider` is `azurekeyvault`.                          | `[]`                                            |